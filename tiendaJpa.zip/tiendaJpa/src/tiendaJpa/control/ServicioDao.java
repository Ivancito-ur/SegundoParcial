package tiendaJpa.control;

import tiendaJpa.entities.Servicio;
import tiendaJpa.utils.Conexion;

public class ServicioDao extends Conexion<Servicio> implements GenericDao<Servicio> {


	public ServicioDao(){
		
	}
	
}
