package tiendaJpa.control;

import tiendaJpa.entities.Servicio;
import tiendaJpa.entities.Tienda;
import tiendaJpa.utils.Conexion;

public class TiendaDao extends Conexion<Tienda> implements GenericDao<Tienda> {
	public TiendaDao(){
    }

}
